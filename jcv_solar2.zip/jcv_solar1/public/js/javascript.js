// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }));
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animated Counter for Statistics
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    const speed = 200; // Adjust animation speed

    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const inc = target / speed;

            if (count < target) {
                counter.innerText = Math.ceil(count + inc);
                setTimeout(updateCount, 1);
            } else {
                counter.innerText = target;
            }
        };
        updateCount();
    });
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            
            // Trigger counter animation when stats section is visible
            if (entry.target.classList.contains('hero-stats')) {
                animateCounters();
            }
        }
    });
}, observerOptions);

// Observe elements for animations
document.addEventListener('DOMContentLoaded', () => {
    // Add animation classes to elements
    const animatedElements = document.querySelectorAll('.service-card, .benefit-card, .mvv-card, .team-member, .testimonial-card, .gallery-item, .hero-stats');
    animatedElements.forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });

    // Navbar background change on scroll
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            } else {
                navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            }
        });
    }
});

// Solar Calculator
// --- Lightbox ---
 // Toggle installation details
        function toggleDetails(id) {
            const details = document.getElementById(id);
            const button = details.previousElementSibling;
            const isExpanded = details.style.display === 'block';
            details.style.display = isExpanded ? 'none' : 'block';
            button.setAttribute('aria-expanded', !isExpanded);
        }

        // Lightbox functionality (unchanged)
        let lightbox = document.getElementById('lightbox');
        let lightboxImage = document.getElementById('lightboxImage');

        function openLightbox(src) {
            lightbox.style.display = 'flex';
            lightboxImage.src = src;
        }

        function closeLightbox() {
            lightbox.style.display = 'none';
        }

        // Debug script to check resource loading
        console.log('CSS loaded:', document.querySelector('link[href="/css/style.css"]').sheet ? 'Yes' : 'No');
        console.log('JS loaded:', typeof window.calculateSavings === 'function' ? 'Yes' : 'No');
        document.addEventListener('DOMContentLoaded', () => {
            console.log('DOM fully loaded, checking image paths...');
            document.querySelectorAll('img').forEach(img => {
                img.addEventListener('error', () => console.log(`Image load failed for ${img.src}`));
            });
        });

// --- Calculator ---
function calculateSavings() {
    const monthlyBill = parseFloat(document.getElementById('monthlyBill').value);
    const roofSize = parseFloat(document.getElementById('roofSize').value);
    const location = document.getElementById('location').value;

    if (isNaN(monthlyBill) || isNaN(roofSize) || roofSize <= 0) {
        alert("Please enter valid values.");
        return;
    }

    // Sun exposure factor
    const sunFactor = {
        high: 5.5,    // kWh/m²/day
        medium: 4.5,
        low: 3.5
    }[location];

    // Conversion constants
    const sqftPerKW = 100; // average roof space needed per kW
    const pricePerUnitINR = 7; // ₹ per unit saved
    const voltage = 230; // Assumed system voltage

    const systemKW = roofSize / sqftPerKW;
    const dailyOutput = systemKW * sunFactor; // kWh/day
    const monthlyOutput = dailyOutput * 30;
    const annualOutput = monthlyOutput * 12;

    const annualSavingsINR = annualOutput * pricePerUnitINR;
    const lifetimeSavingsINR = annualSavingsINR * 25;

    const currentAmps = (systemKW * 1000) / voltage;

    // Display results
    document.getElementById("systemSize").textContent = systemKW.toFixed(1) + " kW";
    document.getElementById("unitsGenerated").textContent = monthlyOutput.toFixed(0) + " kWh";
    document.getElementById("currentOutput").textContent = currentAmps.toFixed(1) + " A";
    document.getElementById("annualSavings").textContent = "₹" + annualSavingsINR.toLocaleString();
    document.getElementById("lifetimeSavings").textContent = "₹" + lifetimeSavingsINR.toLocaleString();
}

// Toggle expandable content
  function toggleContent(id) {
    const content = document.getElementById(id);
    const button = content.previousElementSibling;
    const isExpanded = content.style.display === 'block';
    content.style.display = isExpanded ? 'none' : 'block';
    button.setAttribute('aria-expanded', !isExpanded);
  }

  // Scroll animation for timeline items
  function handleScroll() {
    const items = document.querySelectorAll('.timeline-item');
    items.forEach(item => {
      const rect = item.getBoundingClientRect();
      const isVisible = rect.top < window.innerHeight * 0.75 && rect.bottom >= 0;
      if (isVisible) {
        item.classList.add('visible');
      }
    });
  }

  window.addEventListener('scroll', handleScroll);
  window.addEventListener('load', handleScroll);


// FAQ Functionality
document.addEventListener('DOMContentLoaded', () => {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all FAQ items
            faqItems.forEach(faq => {
                faq.classList.remove('active');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
});

// Contact Form Validation
document.addEventListener('DOMContentLoaded', () => {
    const applicationForm = document.getElementById('applicationForm');
    if (applicationForm) {
        applicationForm.addEventListener('submit', handleApplicationSubmit);
    }
});

function handleApplicationSubmit(e) {
    e.preventDefault();

    document.querySelectorAll('.error-message').forEach(error => {
        error.textContent = '';
    });

    let isValid = true;

    const requiredFields = ['jobTitle', 'fullName', 'email', 'phone', 'resume'];
    requiredFields.forEach(fieldName => {
        const field = document.getElementById(fieldName);
        const errorElement = document.getElementById(fieldName + 'Error');

        if (fieldName === 'resume') {
            if (!field.files.length) {
                errorElement.textContent = 'Please upload a resume';
                field.style.borderColor = 'var(--error-color)';
                isValid = false;
            } else {
                field.style.borderColor = '#e5e7eb';
            }
        } else if (!field.value.trim()) {
            errorElement.textContent = 'This field is required';
            field.style.borderColor = 'var(--error-color)';
            isValid = false;
        } else {
            field.style.borderColor = '#e5e7eb';
        }
    });

    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email.value && !emailRegex.test(email.value)) {
        emailError.textContent = 'Please enter a valid email address';
        email.style.borderColor = 'var(--error-color)';
        isValid = false;
    }

    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phoneError');
    const phoneRegex = /^[\d\s\-\(\)\+]+$/;

    if (phone.value && !phoneRegex.test(phone.value)) {
        phoneError.textContent = 'Please enter a valid phone number';
        phone.style.borderColor = 'var(--error-color)';
        isValid = false;
    }

    const resume = document.getElementById('resume');
    const resumeError = document.getElementById('resumeError');
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

    if (resume.files.length && !allowedTypes.includes(resume.files[0].type)) {
        resumeError.textContent = 'Please upload a PDF, DOC, or DOCX file';
        resume.style.borderColor = 'var(--error-color)';
        isValid = false;
    }

    if (isValid) {
        const submitBtn = applicationForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;

        submitBtn.textContent = 'Submitting...';
        submitBtn.disabled = true;

        setTimeout(() => {
            submitBtn.textContent = 'Application Sent!';
            submitBtn.style.background = 'var(--success-color)';

            setTimeout(() => {
                applicationForm.reset();
                submitBtn.textContent = originalText;
                submitBtn.style.background = 'var(--accent-color)';
                submitBtn.disabled = false;
            }, 2000);
        }, 1000);
    }
}

// Parallax effect for hero sections
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll('.hero, .page-header');
    
    parallaxElements.forEach(element => {
        const speed = 0.5;
        element.style.transform = `translateY(${scrolled * speed}px)`;
    });
});

// Loading animation
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// Add smooth transitions to buttons
document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});

// Service card hover effects
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.service-card, .benefit-card, .mvv-card, .testimonial-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
            this.style.boxShadow = '0 25px 50px -12px rgba(0, 0, 0, 0.25)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'var(--shadow)';
        });
    });
});

// Add typing effect to hero title (optional enhancement)
function typeWriter(element, text, speed = 50) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    type();
}

// Intersection Observer for scroll animations
const scrollAnimationObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
});

// Initialize scroll animations
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.service-card, .benefit-card, .mvv-card, .team-member, .testimonial-card, .process-step, .timeline-item, .cert-item');
    
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = `all 0.6s ease ${index * 0.1}s`;
        scrollAnimationObserver.observe(el);
    });
});
