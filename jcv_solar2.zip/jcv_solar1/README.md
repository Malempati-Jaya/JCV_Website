# JCV Solar - Node.js Application

A Node.js application for JCV Solar, a leading provider of solar energy solutions. This project serves a multi-page website with features like mobile navigation, smooth scrolling, animated counters, a solar savings calculator, gallery lightbox, FAQ functionality, and form validation.

## Project Structure